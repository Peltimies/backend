const NewTestStudentObject = {
  studentcode: 't1234',
  name: 'Testi Opiskelija',
  email: 't1234@jamk.fi',
  studypoints: 0,
  grades: [
    {
      coursecode: 'HTS10600',
      grade: 0,
    },
  ],
};

module.exports = NewTestStudentObject;
